Readme


This readme file provides instructions on how to build, run, and use the prototype web application developed using Visual Studio and C#. The application aims to manage a database of farmers and their associated products. It includes features such as user authentication, user roles, adding farmers and products, and filtering products based on various criteria.



Prerequisites

To successfully build and run the prototype web application, ensure you have the following tools and software installed:

- Visual Studio (version 2022 or later)
- .NET Framework 
- Web browser (Chrome, Firefox, or Edge)

Installation

1. Download the prototype web application files from the provided zip archive.
2. Extract the contents of the zip archive to a directory of your choice.
3. Open Visual Studio.
4. From the Visual Studio menu, select **File > Open > Project/Solution**.
5. Browse to the directory where you extracted the files and select the solution file (.sln) to open the project.
6. Visual Studio will load the project and its dependencies.

Running the Application

1. Ensure that the project is selected in the **Solution Explorer** pane.
2. Press **Ctrl + F5** or select **Debug > Start Without Debugging** to build and run the application.
3. The web application will launch in your default web browser.

Usage

User Roles

The prototype web application supports two user roles: **farmer** and **employee**. Each role has specific privileges and access to different functionality.

- **Farmer**: Farmers can log into the website to manage their profile and products. They can add new products associated with their profile.
- **Employee**: Employees can log into the website to manage the database. They can add new farmers and view a list of all products supplied by specific farmers. Employees can also filter the displayed list of products based on the date range or product type.

Logging In

1. Open the web application in your browser.
2. Click on the **Login** link in the navigation bar.
3. Enter your username and password in the provided fields.
4. Click the **Login** button to authenticate.

Adding a Farmer

1. Log in to the web application with an employee account.
2. From the employee dashboard, click on the **Add Farmer** button.
3. Fill in the required fields, such as farmer name, address, and contact information.
4. Click the **Save** button to add the farmer to the database.

Adding a Product

1. Log in to the web application with a farmer account.
2. From the farmer dashboard, click on the **Add Product** button.
3. Provide details for the product, such as name, description, and price.
4. Click the **Save** button to add the product to your profile in the database.

Viewing Farmer's Products

1. Log in to the web application with an employee account.
2. From the employee dashboard, click on the **View Farmers** button.
3. Select the desired farmer from the list.
4. The displayed list will show all the products ever supplied by the selected farmer.

Filtering Products

1. Log in to the web application with an employee account.
2. From the employee dashboard, click on the **View Farmers** button.
3. Select the desired farmer from the list.
4. To

 filter the displayed list of products, use the provided date range and product type filters.
5. Click the **Apply Filters** button to update the list according to the selected criteria.

Sample Data

The prototype web application includes sample data to provide a demonstration without requiring extensive data entry. The sample data includes pre-populated farmers and products with realistic information. It allows the bid committee to explore and evaluate the application's features easily.

Concerns Addressed

The prototype web application addresses the following concerns of the bid committee:

Accuracy of the Data

The sample data included in the application provides accurate representations of farmers and their products. However, please note that the data is for demonstration purposes only and may not reflect real-world scenarios.

Website Appearance

The prototype web application aims to have an intuitive and visually appealing design. The user interface has been developed with a focus on user experience and modern web design principles. However, further improvements and customization can be made based on specific requirements and feedback.

Website Usability

The application provides user-friendly features and interfaces for both farmers and employees. User authentication ensures that only authorized users can access specific information and perform relevant actions. The prototype includes basic functionality, and additional features can be implemented based on the committee's requirements.


